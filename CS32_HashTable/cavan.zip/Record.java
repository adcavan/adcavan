import java.util.*;
import java.io.*;

//Object Record
public class Record {
	String student_no = "";
	String firstname = "";
	String surname = "";
	String doB = "";
	String gender = "";	
	Record next;						
}